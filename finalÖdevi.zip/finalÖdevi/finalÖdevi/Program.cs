﻿using System;
using System.Collections.Generic;

namespace GrafikAlgoritmalari
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dijkstra Algoritması:");
            DijkstraAlgoritmasi();

            Console.WriteLine("\nKruskal Algoritması:");
            KruskalAlgoritmasi();

            Console.WriteLine("\nPrim Algoritması:");
            PrimAlgoritmasi();
        }
        static void DijkstraAlgoritmasi()
        {
            // Grafiği tanımla
            int[,] grafik =  {
                //6x6lık bir matris tanımlanıp düğümler ve ağırlıkları veriidi
                { 0, 10, 20, 0, 0, 0 },
                { 10, 0, 0, 50, 10, 0 },
                { 20, 0, 0, 20, 33, 0 },
                { 0, 50, 20, 0, 20, 2 },
                { 0, 10, 33, 20, 0, 1 },
                { 0, 0,  0,  2,  1, 0 }
            };

            // Dijkstra algoritmasını çalıştır
            Dijkstra(grafik, 0);
        }

        public static void Dijkstra(int[,] grafik, int baslangicDugumu)
        {
            int dugumSayisi = grafik.GetLength(0); // Düğüm sayısını al
            int[] uzakliklar = new int[dugumSayisi]; // Uzaklıkları tutacak dizi
            bool[] enKisaYolKumesi = new bool[dugumSayisi]; // Ziyaret edilen düğümleri tutacak dizi

            // Başlangıç değerlerini ata
            for (int i = 0; i < dugumSayisi; i++)
            {
                uzakliklar[i] = int.MaxValue;
                // henüz işlenmemiş düğümleri belirtir.
                enKisaYolKumesi[i] = false;
            }

            uzakliklar[baslangicDugumu] = 0; // Başlangıç düğümünün uzaklığı 0

            // Tüm düğümler için işlemi tekrarla
            for (int count = 0; count < dugumSayisi - 1; count++)
            {
                int u = MinUzaklik(uzakliklar, enKisaYolKumesi, dugumSayisi); // En kısa uzaklıkta olan düğümü al
                enKisaYolKumesi[u] = true; // Düğümü işaretle

                // Seçilen düğüme komşu olan tüm düğümler için işlemleri tekrarla
                for (int v = 0; v < dugumSayisi; v++)
                {
                    if (!enKisaYolKumesi[v] && Convert.ToBoolean(grafik[u, v]) && uzakliklar[u] != int.MaxValue && uzakliklar[u] + grafik[u, v] < uzakliklar[v])
                    {
                        uzakliklar[v] = uzakliklar[u] + grafik[u, v]; // Daha kısa bir yol bulunduğunda uzaklığı güncelle
                    }
                }
            }

            Yazdir(uzakliklar, dugumSayisi); // Sonuçları yazdır
        }

        private static int MinUzaklik(int[] uzakliklar, bool[] enKisaYolKumesi, int dugumSayisi)
        {
            int min = int.MaxValue;
            int minIndex = -1;

            // En kısa uzaklığı bul
            for (int v = 0; v < dugumSayisi; v++)
            {
                //enKisaYolKumesi[v]:Düğüm, daha önce işlenmemişse (false ise) ve Düğümün uzaklığı, şu ana kadar hesaplanan en küçük uzaklıktan daha küçük veya eşitse değerler güncellenir
                if (!enKisaYolKumesi[v] && uzakliklar[v] <= min)
                {
                    min = uzakliklar[v];
                    minIndex = v;
                }
            }

            return minIndex;
        }

        private static void Yazdir(int[] uzakliklar, int dugumSayisi)
        {
            Console.WriteLine("Düğüm    Kaynaktan Uzaklık");
            for (int i = 0; i < dugumSayisi; i++)
            {
                Console.WriteLine($"{i}\t  {uzakliklar[i]}");
            }
        }

        static void KruskalAlgoritmasi()
        {
            // Grafiği oluştur ve kenarları ekle
            int dugumSayisi = 4;
            Graf graf = new Graf(dugumSayisi);
            //0 düğümünden 1 düğümüne ağırlık 10
            graf.KenarEkle(0, 1, 10);
            graf.KenarEkle(0, 2, 6);
            graf.KenarEkle(0, 3, 5);
            graf.KenarEkle(1, 3, 15);
            graf.KenarEkle(2, 3, 4);

            // Kruskal algoritmasını çalıştır
            graf.KruskalAlgoritmasi();
        }
        //bu interface ile compare to metodunu içermesini gerektirir
        public class Kenar : IComparable<Kenar>
        {
            //Kenarın başlangıç düğümünü temsil eder.
            public int Kaynak { get; set; }
            // Kenarın bitiş düğümünü temsil eder.
            public int Hedef { get; set; }
            //Kenarın ağırlığını temsil eder.
            public int Agirlik { get; set; }

            //iki tane kenar nesnesini karşılaştırır
            public int CompareTo(Kenar karsilastirKenar)
            {
                return this.Agirlik - karsilastirKenar.Agirlik; // Ağırlığa göre karşılaştır
            }
        }

        public class Graf
        {
            public int DugumSayisi { get; set; }
            public List<Kenar> Kenarlar { get; set; }

            public Graf(int dugumSayisi)
            {
                DugumSayisi = dugumSayisi;
                Kenarlar = new List<Kenar>();
            }

            public void KenarEkle(int kaynak, int hedef, int agirlik)
            {
                Kenarlar.Add(new Kenar() { Kaynak = kaynak, Hedef = hedef, Agirlik = agirlik });
            }

            public void KruskalAlgoritmasi()
            {
                List<Kenar> sonuc = new List<Kenar>();
                //i=kenarları sıralamak için, e= ağaçta bulunan kenar sayısını saymak için
                int i = 0, e = 0;

                Kenarlar.Sort(); // Kenarları ağırlıklarına göre sırala

                // Her düğümün ebeveynini temsil eden bir dizi oluşturulur
                int[] ebeveyn = new int[DugumSayisi];
                for (int v = 0; v < DugumSayisi; ++v)
                    ebeveyn[v] = v;

                //Ağaçta bulunan kenar sayısı, düğüm sayısından bir eksik olana kadar devam eden bir döngü oluşturulur.
                while (e < DugumSayisi - 1)
                {
                    Kenar siradakiKenar = Kenarlar[i++];
                    // Seçilen kenarın başlangıç ve bitiş düğümlerinin ebeveynleri bulunur.
                    int x = Bul(ebeveyn, siradakiKenar.Kaynak);
                    int y = Bul(ebeveyn, siradakiKenar.Hedef);

                    //Seçilen kenarın başlangıç ve bitiş düğümleri aynı ağaçta değilse, bu kenar minimum maliyetli ağaca eklenir.
                    if (x != y)
                    {
                        sonuc.Add(siradakiKenar);
                        e++;
                        //Seçilen kenarın başlangıç ve bitiş düğümlerini birleştir.
                        Birlesme(ebeveyn, x, y);
                    }
                }

                Console.WriteLine("Minimum Maliyetli Ağaçtaki Kenarlar:");
                foreach (var kenar in sonuc)
                {
                    // Her kenarın başlangıç düğümü, bitiş düğümü ve ağırlığını ekrana yazdır
                    Console.WriteLine($"{kenar.Kaynak} -- {kenar.Hedef} == {kenar.Agirlik}");
                }
            }

            private int Bul(int[] ebeveyn, int i)
            {
                if (ebeveyn[i] == i)
                    return i;
                return Bul(ebeveyn, ebeveyn[i]);
            }

            private void Birlesme(int[] ebeveyn, int x, int y)
            {
                int xKok = Bul(ebeveyn, x);
                int yKok = Bul(ebeveyn, y);
                ebeveyn[xKok] = yKok;
            }
        }

        static void PrimAlgoritmasi()
        {
            // Grafiği tanımla
            Prim t = new Prim();
            int[,] grafik =  {
                { 0, 2, 0, 6, 0 },
                { 2, 0, 3, 8, 5 },
                { 0, 3, 0, 0, 7 },
                { 6, 8, 0, 0, 9 },
                { 0, 5, 7, 9, 0 }
            };

            // Prim algoritmasını çalıştır
            t.PrimMST(grafik);
        }

        public class Prim
        {
            private static int V = 5;

            int MinAnahtar(int[] anahtar, bool[] mstKumesi)
            {
                //Minimum anahtar ve minimum anahtara sahip düğümün indisini tutacak değişkenler başlatılır.
                int min = int.MaxValue, minDizin = -1;

                for (int v = 0; v < V; v++)
                    //Düğüm, minimum ağaç kümesine dahil edilmemişse (false ise) ve Düğümün anahtarı, şu ana kadar bulunan minimum anahtardan daha küçükse,
                    if (!mstKumesi[v] && anahtar[v] < min)
                    {
                        //güncelleme işlemi
                        min = anahtar[v];
                        minDizin = v;
                    }

                return minDizin;
            }

            void MSTYazdir(int[] ebeveyn, int[,] grafik)
            {
                Console.WriteLine("Kenar \tAğırlık");
                for (int i = 1; i < V; i++)
                    Console.WriteLine($"{ebeveyn[i]} - {i}\t{grafik[i, ebeveyn[i]]}");
            }

            public void PrimMST(int[,] grafik)
            {
                //minimum maliyetli ağacın ebeveynlerini tutar.
                int[] ebeveyn = new int[V];
                //her düğüme atanmış olan anahtar değerlerini (uzaklıkları) tutar. 
                int[] anahtar = new int[V];
                //minimum ağaç kümesine dahil edilen düğümleri belirtir.
                bool[] mstKumesi = new bool[V];

                for (int i = 0; i < V; i++)
                {
                    anahtar[i] = int.MaxValue;
                    mstKumesi[i] = false;
                }

                anahtar[0] = 0;
                ebeveyn[0] = -1;

                for (int count = 0; count < V - 1; count++)
                {
                    //Henüz minimum ağaç kümesine dahil edilmemiş düğümler arasından minimum anahtara sahip düğüm seçilir.
                    int u = MinAnahtar(anahtar, mstKumesi);
                    //Seçilen düğüm, minimum ağaç kümesine dahil edilir.
                    mstKumesi[u] = true;

                    //Seçilen düğüm ile henüz minimum ağaç kümesine dahil edilmemiş diğer düğümler arasında bir döngü oluşturulur.
                    for (int v = 0; v < V; v++)
                        //Düğümler arasında bir kenar varsa ve bu kenar daha önce minimum ağaç kümesine dahil edilmemişse ve bu kenarın ağırlığı, diğer düğümün anahtar değerinden daha küçükse, bu kenarın ağırlığı ve ebeveyni güncellenir.
                        if (grafik[u, v] != 0 && !mstKumesi[v] && grafik[u, v] < anahtar[v])
                        {
                            ebeveyn[v] = u;
                            anahtar[v] = grafik[u, v];
                        }
                }

                MSTYazdir(ebeveyn, grafik);
            }
        }
    }
}
